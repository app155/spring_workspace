package polymorphism;

public class LgTV implements TV {
	public void powerOn() {
		System.out.println("LgTV ----- 전원을 킨다.");
	}
	
	public void powerOff() {
		System.out.println("LgTV ----- 전원을 끈다.");
	}
	
	public void volumeUp() {
		System.out.println("LgTV ----- 볼륨을 높인다.");
	}
	
	public void volumeDown() {
		System.out.println("LgTV ----- 볼륨을 줄인다.");
	}
}
