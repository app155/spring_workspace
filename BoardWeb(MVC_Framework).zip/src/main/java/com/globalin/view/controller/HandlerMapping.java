package com.globalin.view.controller;

import java.util.HashMap;
import java.util.Map;

import com.globalin.view.board.DeleteBoardController;
import com.globalin.view.board.GetBoardController;
import com.globalin.view.board.GetBoardListController;
import com.globalin.view.board.InsertBoardController;
import com.globalin.view.board.UpdateBoardController;
import com.globalin.view.user.LoginController;
import com.globalin.view.user.LogoutController;

public class HandlerMapping {
	private Map<String, Controller> mappings;
	
	public HandlerMapping() {
		mappings = new HashMap<>();
		mappings.put("/login.do", new LoginController());
		mappings.put("/getBoardList.do", new GetBoardListController());
		mappings.put("/getBoard.do", new GetBoardController());
		mappings.put("/insertBoard.do", new InsertBoardController());
		mappings.put("/updateBoard.do", new UpdateBoardController());
		mappings.put("/deleteBoard.do", new DeleteBoardController());
		mappings.put("/logout.do", new LogoutController());
	}
	
	public Controller getController(String path) {
		return mappings.get(path);
	}
}
