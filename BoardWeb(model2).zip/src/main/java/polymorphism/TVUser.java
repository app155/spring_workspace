package polymorphism;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

/*
 * 	1. GenericXmlApplicationContext
 * 		- 파일 시스템이나 클래스 경로에 있는 xml 설정파일을 로딩하여 구동하는 컨테이너
 * 
 * 	2. XmlWebApplicationContext
 * 		- 웹 기반 스프링 어플리케이션을 개발할 때 사용하는 컨테이너
 */

public class TVUser {

	public static void main(String[] args) {
		
		// 1. Spring 컨테이너 구동
		AbstractApplicationContext factory = new GenericXmlApplicationContext("applicationContext.xml");
		

		// 2. Spring 컨테이너로부터 필요한 객체 요청(Lookup)
		TV tv = (TV)factory.getBean("tv");
		TV tv2 = (TV)factory.getBean("tv");
		TV tv3 = (TV)factory.getBean("tv");
		
		
		tv.powerOn();
		tv.volumeUp();
		tv.volumeDown();
		tv.powerOff();
		
		// 3. Spring 컨테이너 종료
		factory.close();
		
		
		/*
		TV tv1 = new SamsungTV();
		// TV tv2 = new SamsungTV();
		// TV tv3 = new SamsungTV();
		TV tv2 = tv1;
		TV tv3 = tv2;
		*/
		
		/*
		// SamsungTV tv = new SamsungTV();
		// LgTV tv = new LgTV();
		// TV tv = new SamsungTV();
		BeanFactory factory = new BeanFactory();
		
		TV tv = (TV)factory.getBean("lg");
		tv.powerOn();
		tv.volumeUp();
		tv.volumeDown();
		tv.powerOff();
		
		LgTV tv = new LgTV();
		tv.turnOn();
		tv.SoundUp();
		tv.SoundDown();
		tv.turnOff();
		*/
	}

}
